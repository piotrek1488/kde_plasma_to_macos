var plasma = getApiVersion(1);

var layout = {
    "desktops": [
        {
            "applets": [
                {
                    "config": {
                        "/ConfigDialog": {
                            "DialogHeight": "630",
                            "DialogWidth": "810"
                        },
                        "/General": {
                            "appearance": "2"
                        }
                    },
                    "geometry.height": 0,
                    "geometry.width": 0,
                    "geometry.x": 0,
                    "geometry.y": 0,
                    "plugin": "com.jaxparrow07.macoswidgets.calendar",
                    "title": "macOS Calendar"
                },
                {
                    "config": {
                        "/ConfigDialog": {
                            "DialogHeight": "630",
                            "DialogWidth": "810"
                        },
                        "/General": {
                            "appearance": "2"
                        }
                    },
                    "geometry.height": 0,
                    "geometry.width": 0,
                    "geometry.x": 0,
                    "geometry.y": 0,
                    "plugin": "com.jaxparrow07.macoswidgets.timer",
                    "title": "macOS Timer"
                },
                {
                    "config": {
                        "/ConfigDialog": {
                            "DialogHeight": "630",
                            "DialogWidth": "810"
                        },
                        "/General": {
                            "appearance": "2"
                        }
                    },
                    "geometry.height": 0,
                    "geometry.width": 0,
                    "geometry.x": 0,
                    "geometry.y": 0,
                    "plugin": "com.jaxparrow07.macoswidgets.weather",
                    "title": "macOS Weather"
                },
                {
                    "config": {
                        "/ConfigDialog": {
                            "DialogHeight": "630",
                            "DialogWidth": "810"
                        },
                        "/General": {
                            "appearance": "2"
                        }
                    },
                    "geometry.height": 0,
                    "geometry.width": 0,
                    "geometry.x": 0,
                    "geometry.y": 0,
                    "plugin": "com.jaxparrow07.macoswidgets.clock-square",
                    "title": "macOS Clock Digital"
                },
                {
                    "config": {
                        "/ConfigDialog": {
                            "DialogHeight": "630",
                            "DialogWidth": "810"
                        },
                        "/General": {
                            "appearance": "2",
                            "styleMode": "0"
                        }
                    },
                    "geometry.height": 0,
                    "geometry.width": 0,
                    "geometry.x": 0,
                    "geometry.y": 0,
                    "plugin": "com.jaxparrow07.macoswidgets.music",
                    "title": "macOS Music"
                }
            ],
            "config": {
                "/": {
                    "ItemGeometries-1920x1080": "Applet-94:32,32,432,208,0;Applet-97:32,256,208,208,0;Applet-93:256,256,208,208,0;Applet-88:32,480,432,208,0;Applet-98:32,704,432,208,0;",
                    "ItemGeometries-1920x983": "Applet-97:32,48,160,160,0;Applet-88:32,224,352,160,0;Applet-94:32,400,352,352,0;Applet-96:208,48,176,160,0;Applet-93:384,704,352,160,0;",
                    "ItemGeometriesHorizontal": "Applet-94:32,32,432,208,0;Applet-97:32,256,208,208,0;Applet-93:256,256,208,208,0;Applet-88:32,480,432,208,0;Applet-98:32,704,432,208,0;",
                    "formfactor": "0",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.image"
                }
            },
            "wallpaperPlugin": "org.kde.image"
        }
    ],
    "panels": [
        {
            "alignment": "left",
            "applets": [
                {
                    "config": {
                        "/General": {
                            "expanding": "false",
                            "length": "10"
                        }
                    },
                    "plugin": "org.kde.plasma.panelspacer"
                },
                {
                    "config": {
                        "/": {
                            "popupHeight": "343",
                            "popupWidth": "200"
                        },
                        "/Apperance": {
                            "buttonHeight": "38",
                            "cmdList": "kinfocenter,systemsettings,plasma-discover,xkill,systemctl suspend,qdbus org.kde.LogoutPrompt /LogoutPrompt promptReboot,qdbus org.kde.LogoutPrompt /LogoutPrompt promptShutDown,qdbus org.freedesktop.ScreenSaver /ScreenSaver Lock,qdbus org.kde.LogoutPrompt /LogoutPrompt promptLogout",
                            "iconList": "help-hint,settings-configure,update-none,error,system-suspend,system-reboot,system-shutdown,system-lock-screen,system-log-out",
                            "labelList": "About This Computer,System Preferences...,App Store...,Force Quit...,Sleep,Restart...,Shut Down...,Lock Screen,Log Out",
                            "separatorList": "false,false,false,false,false,false,false,false,false",
                            "showIcons": "true",
                            "width": "200"
                        },
                        "/ConfigDialog": {
                            "DialogHeight": "630",
                            "DialogWidth": "810"
                        }
                    },
                    "plugin": "org.51n7.kMenu"
                },
                {
                    "config": {
                        "/Appearance": {
                            "widgetButtonsAuroraeTheme": "MacSequoia-Dark",
                            "widgetButtonsIconsTheme": "Aurorae",
                            "widgetButtonsMargins": "8",
                            "widgetElements": "spacer,windowCloseButton,windowMinimizeButton,windowMaximizeButton,spacer",
                            "widgetElementsDisabledMode": "Hide",
                            "widgetSpacing": "8",
                            "widgetToolTipMode": "Disabled",
                            "windowTitleFontSize": "10",
                            "windowTitleHideEmpty": "true",
                            "windowTitleUndefined": "Finder   Files  Edit  View  Go  Window  Help"
                        },
                        "/Behavior": {
                            "widgetActiveTaskFilterNotMaximized": "true"
                        },
                        "/ConfigDialog": {
                            "DialogHeight": "540",
                            "DialogWidth": "720"
                        }
                    },
                    "plugin": "com.github.antroids.application-title-bar"
                },
                {
                    "config": {
                        "/Appearance": {
                            "activityIcon": "false",
                            "altTxt": "   Finder        File         Edit         View         Go         Window         Help",
                            "fontSize": "13",
                            "isCaps": "true",
                            "visible": "false"
                        },
                        "/ConfigDialog": {
                            "DialogHeight": "630",
                            "DialogWidth": "810"
                        }
                    },
                    "plugin": "com.ajxcodes.macappmenu"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.appmenu"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.panelspacer"
                },
                {
                    "config": {
                        "/": {
                            "popupHeight": "433",
                            "popupWidth": "288"
                        }
                    },
                    "plugin": "com.jaxparrow07.macoswidgets.weatherpanel"
                },
                {
                    "config": {
                        "/General": {
                            "expanding": "false",
                            "length": "10"
                        }
                    },
                    "plugin": "org.kde.plasma.panelspacer"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.systemtray"
                },
                {
                    "config": {
                        "/General": {
                            "expanding": "false",
                            "length": "10"
                        }
                    },
                    "plugin": "org.kde.plasma.panelspacer"
                },
                {
                    "config": {
                        "/": {
                            "popupHeight": "351",
                            "popupWidth": "300"
                        },
                        "/Appearance": {
                            "animations": "true",
                            "customButtonImage": "step_object_Controller-symbolic",
                            "darkTheme": "MacSequoiaDark",
                            "layout": "3",
                            "lightTheme": "MacSequoiaLight",
                            "scale": "95",
                            "showPercentage": "true",
                            "showScreenshot": "true",
                            "transparency": "true",
                            "transparencyLevel": "50",
                            "useCustomButtonImage": "true"
                        },
                        "/ConfigDialog": {
                            "DialogHeight": "630",
                            "DialogWidth": "810"
                        }
                    },
                    "plugin": "KdeControlStation"
                },
                {
                    "config": {
                        "/General": {
                            "expanding": "false",
                            "length": "10"
                        }
                    },
                    "plugin": "org.kde.plasma.panelspacer"
                },
                {
                    "config": {
                        "/": {
                            "popupHeight": "451",
                            "popupWidth": "810"
                        },
                        "/Appearance": {
                            "customDateFormat": "",
                            "dateFormat": "custom",
                            "enabledCalendarPlugins": "a,l,t,e,r,n,a,t,e,c,a,l,e,n,d,a,r,",
                            "firstDayOfWeek": "0",
                            "fontFamily": "SF Pro Display",
                            "fontWeight": "400",
                            "showDate": "false",
                            "showWeekNumbers": "true"
                        },
                        "/ConfigDialog": {
                            "DialogHeight": "540",
                            "DialogWidth": "720"
                        }
                    },
                    "plugin": "org.kde.plasma.digitalclock"
                }
            ],
            "config": {
                "/": {
                    "formfactor": "2",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.image"
                },
                "/ConfigDialog": {
                    "DialogHeight": "175",
                    "DialogWidth": "3840"
                }
            },
            "height": 2.25,
            "hiding": "normal",
            "lengthMode": "fill",
            "location": "top",
            "maximumLength": 96,
            "minimumLength": 96,
            "offset": 0,
            "opacity": "adaptive"
        },
        {
            "alignment": "center",
            "applets": [
                {
                    "config": {
                        "/": {
                            "popupHeight": "375",
                            "popupWidth": "525"
                        },
                        "/ConfigDialog": {
                            "DialogHeight": "630",
                            "DialogWidth": "810"
                        },
                        "/General": {
                            "backgroundOpacity": "55",
                            "customButtonImage": "view-app-grid",
                            "favoritesPortedToKAstats": "true",
                            "gridColumns": "6",
                            "headerActionsMigrated": "true",
                            "iconMigratedFrom17": "true",
                            "knownApps": "org.kde.akregator.desktop,org.kde.ark.desktop,org.bleachbit.BleachBit.desktop,org.gnome.Calendar.desktop,org.gnome.clocks.desktop,org.kde.contactprintthemeeditor.desktop,org.kde.contactthemeeditor.desktop,org.kde.drkonqi.coredump.gui.desktop,org.kde.discover.desktop,org.kde.dolphin.desktop,org.kde.dragonplayer.desktop,org.kde.elisa.desktop,org.kde.plasma.emojier.desktop,org.fedoraproject.MediaWriter.desktop,org.kde.filelight.desktop,org.gnome.Nautilus.desktop,org.mozilla.firefox.desktop,firewall-config.desktop,org.kde.kwatchgnupg.desktop,org.kde.gwenview.desktop,org.kde.khelpcenter.desktop,org.kde.kinfocenter.desktop,im-chooser.desktop,org.kde.kjournaldbrowser.desktop,org.kde.kaddressbook.desktop,org.kde.kamoso.desktop,org.kde.kate.desktop,org.kde.kcalc.desktop,org.kde.kcharselect.desktop,org.kde.kdeconnect.app.desktop,org.kde.kdeconnect.sms.desktop,org.kde.partitionmanager.desktop,org.kde.kdebugsettings.desktop,org.kde.kfind.desktop,org.kde.kgpg.desktop,org.kde.kleopatra.desktop,org.kde.kmahjongg.desktop,org.kde.kmail2.desktop,org.kde.headerthemeeditor.desktop,org.kde.akonadiimportwizard.desktop,org.kde.kmines.desktop,org.kde.kmouth.desktop,org.kde.kolourpaint.desktop,org.kde.konsole.desktop,org.kde.kontact.desktop,org.kde.korganizer.desktop,org.kde.kpat.desktop,org.kde.krdc.desktop,org.kde.krfb.desktop,org.kde.ktnef.desktop,kvantummanager.desktop,org.kde.kwalletmanager.desktop,org.kde.kwrite.desktop,libreoffice-calc.desktop,libreoffice-draw.desktop,libreoffice-impress.desktop,libreoffice-math.desktop,libreoffice-writer.desktop,org.gnome.Maps.desktop,org.kde.kmenuedit.desktop,org.kde.neochat.desktop,org.kde.okular.desktop,org.kde.pimdataexporter.desktop,org.freedesktop.GnomeAbrt.desktop,org.kde.qrca.desktop,org.kde.sieveeditor.desktop,org.kde.skanpage.desktop,org.kde.spectacle.desktop,org.kde.plasma-systemmonitor.desktop,systemsettings.desktop,org.gnome.Terminal.desktop,vlc.desktop,org.gnome.Weather.desktop,org.kde.plasma-welcome.desktop",
                            "launchCounts": "kvantummanager.desktop=5,org.kde.dolphin.desktop=48",
                            "overrideRadius": "true",
                            "powerButtonsMigrated": "true",
                            "recentApps": "org.kde.dolphin.desktop,kvantummanager.desktop",
                            "terminalShell": "/bin/zsh",
                            "useCustomButtonImage": "true"
                        }
                    },
                    "plugin": "dev.xarbit.appgrid"
                },
                {
                    "config": {
                        "/ConfigDialog": {
                            "DialogHeight": "540",
                            "DialogWidth": "720"
                        },
                        "/General": {
                            "launchers": "applications:org.gnome.Nautilus.desktop,applications:org.mozilla.firefox.desktop,applications:org.kde.kcalc.desktop,applications:org.kde.gwenview.desktop,applications:org.kde.elisa.desktop,applications:org.kde.konsole.desktop,applications:org.kde.kate.desktop,applications:org.kde.discover.desktop,applications:systemsettings.desktop"
                        }
                    },
                    "plugin": "org.kde.plasma.icontasks"
                },
                {
                    "config": {
                        "/": {
                            "popupHeight": "375",
                            "popupWidth": "525"
                        },
                        "/ConfigDialog": {
                            "DialogHeight": "630",
                            "DialogWidth": "810"
                        }
                    },
                    "plugin": "plasmoid-ikalendar"
                }
            ],
            "config": {
                "/": {
                    "formfactor": "2",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.image"
                }
            },
            "height": 4,
            "hiding": "dodgewindows",
            "lengthMode": "fit",
            "location": "bottom",
            "maximumLength": 120,
            "minimumLength": 120,
            "offset": 0,
            "opacity": "adaptive"
        }
    ],
    "serializationFormatVersion": "1"
}
;

plasma.loadSerializedLayout(layout);
